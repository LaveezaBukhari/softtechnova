"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface GitHubStatsData {
  totalRepos: number
  totalStars: number
  totalForks: number
  totalCommits: number
  contributions: number
  user: {
    login: string
    name: string | null
    bio: string | null
    public_repos: number
    followers: number
    following: number
  }
}

export function GitHubStats() {
  const [stats, setStats] = useState<GitHubStatsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)

  useEffect(() => {
    fetchGitHubStats()

    // Refresh stats every 5 minutes
    const interval = setInterval(fetchGitHubStats, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY

      // Show stats when scrolling up or at top, hide when scrolling down
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }

      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  const fetchGitHubStats = async () => {
    try {
      const response = await fetch("/api/github/stats")
      if (!response.ok) {
        throw new Error("Failed to fetch GitHub stats")
      }
      const data = await response.json()
      setStats(data)
      setError(null)
    } catch (err) {
      console.error("Error fetching GitHub stats:", err)
      setError("Failed to load stats")
      // Set fallback data
      setStats({
        totalRepos: 12,
        totalStars: 6,
        totalForks: 0,
        totalCommits: 45,
        contributions: 45,
        user: {
          login: "LaveezaBukhari",
          name: "Laveeza Bukhari",
          bio: "Creative Technologist",
          public_repos: 12,
          followers: 0,
          following: 1,
        },
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="fixed top-1/2 right-6 transform -translate-y-1/2 z-40"
      >
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20">
          <div className="text-center mb-3">
            <h3 className="text-white font-semibold text-sm">Loading GitHub Stats</h3>
            <div className="w-2 h-2 bg-yellow-400 rounded-full mx-auto mt-1 animate-pulse" />
          </div>
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="w-16 h-3 bg-white/20 rounded animate-pulse" />
                <div className="w-8 h-3 bg-white/20 rounded animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{
        opacity: isVisible ? 1 : 0,
        x: isVisible ? 0 : 100,
      }}
      transition={{ duration: 0.3 }}
      className="fixed top-1/2 right-6 transform -translate-y-1/2 z-40"
    >
      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 space-y-3">
        <div className="text-center mb-3">
          <h3 className="text-white font-semibold text-sm">Live GitHub Stats</h3>
          <div className={`w-2 h-2 rounded-full mx-auto mt-1 ${error ? "bg-red-400" : "bg-green-400 animate-pulse"}`} />
          {error && <p className="text-red-300 text-xs mt-1">{error}</p>}
        </div>

        {stats &&
          [
            { label: "Repos", value: stats.totalRepos, icon: "📁" },
            { label: "Stars", value: stats.totalStars, icon: "⭐" },
            { label: "Commits", value: stats.totalCommits, icon: "📝" },
            { label: "Contributions", value: stats.contributions, icon: "🔥" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              className="flex items-center justify-between text-sm"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <span className="text-white/70 flex items-center">
                <span className="mr-2">{stat.icon}</span>
                {stat.label}
              </span>
              <span className="text-cyan-300 font-semibold">{stat.value}</span>
            </motion.div>
          ))}

        {/* GitHub Profile Link */}
        <motion.a
          href={`https://github.com/${stats?.user.login}`}
          target="_blank"
          rel="noopener noreferrer"
          className="block text-center text-xs text-purple-300 hover:text-purple-200 transition-colors mt-2 pt-2 border-t border-white/10"
          whileHover={{ scale: 1.05 }}
        >
          View on GitHub →
        </motion.a>
      </div>
    </motion.div>
  )
}
