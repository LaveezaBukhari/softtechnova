"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface VoiceCommandsProps {
  onSectionChange: (section: string) => void
}

export function VoiceCommands({ onSectionChange }: VoiceCommandsProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [isSupported, setIsSupported] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined" && "webkitSpeechRecognition" in window) {
      setIsSupported(true)
    }
  }, [])

  const startListening = () => {
    if (!isSupported) return

    const recognition = new (window as any).webkitSpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event: any) => {
      const command = event.results[0][0].transcript.toLowerCase()
      setTranscript(command)
      processVoiceCommand(command)
    }

    recognition.onend = () => {
      setIsListening(false)
    }

    recognition.onerror = () => {
      setIsListening(false)
    }

    recognition.start()
  }

  const processVoiceCommand = (command: string) => {
    if (command.includes("go to projects") || command.includes("show projects")) {
      document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })
      onSectionChange("projects")
    } else if (command.includes("go to about") || command.includes("show about")) {
      document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
      onSectionChange("about")
    } else if (command.includes("go to contact") || command.includes("show contact")) {
      document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
      onSectionChange("contact")
    } else if (command.includes("go to home") || command.includes("go home")) {
      document.getElementById("hero")?.scrollIntoView({ behavior: "smooth" })
      onSectionChange("hero")
    }
  }

  if (!isSupported) return null

  return (
    <div className="fixed top-24 right-6 z-40">
      <motion.button
        onClick={startListening}
        disabled={isListening}
        className={`p-3 rounded-full backdrop-blur-sm border transition-all duration-300 ${
          isListening
            ? "bg-red-500/20 border-red-500/30 text-red-300"
            : "bg-white/10 border-white/20 text-white/70 hover:bg-white/20 hover:text-white"
        }`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"
          />
        </svg>
      </motion.button>

      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute top-14 right-0 bg-white/10 backdrop-blur-md rounded-lg p-3 border border-white/20 min-w-48"
          >
            <p className="text-white/80 text-sm text-center">🎤 Listening...</p>
            <p className="text-white/60 text-xs text-center mt-1">Try: "Go to projects"</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
