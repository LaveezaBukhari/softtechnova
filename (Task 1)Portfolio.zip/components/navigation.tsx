"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ThemeToggle } from "./theme-toggle"

interface NavigationProps {
  currentSection: string
}

export function Navigation({ currentSection }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY

      // Show nav when scrolling up or at top, hide when scrolling down
      if (currentScrollY < lastScrollY || currentScrollY < 100) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }

      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  const navItems = [
    { id: "hero", label: "Home" },
    { id: "about", label: "About" },
    { id: "skills", label: "Skills" },
    { id: "projects", label: "Projects" },
    { id: "testimonials", label: "Testimonials" },
    { id: "contact", label: "Contact" },
  ]

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsOpen(false)
  }

  const downloadResume = () => {
    // Create a temporary link to download resume
    const link = document.createElement("a")
    link.href = "/placeholder.svg?height=800&width=600" // Replace with actual resume PDF
    link.download = "Sardar_Muhammad_Ahsan_Khan_Resume.pdf"
    link.click()
  }

  return (
    <motion.nav
      className="fixed top-6 inset-x-0 mx-auto z-50 w-auto flex justify-center"
      initial={{ y: -100, opacity: 0 }}
      animate={{
        y: isVisible ? 0 : -100,
        opacity: isVisible ? 1 : 0,
      }}
      transition={{ duration: 0.3 }}
    >
      <div className="bg-white/10 dark:bg-black/20 backdrop-blur-md rounded-full border border-white/20 px-6 py-3 shadow-lg relative z-50 mx-auto">
        <div className="flex items-center space-x-4 lg:space-x-6">
          {/* Logo */}
          <motion.div
            className="text-lg sm:text-xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent cursor-pointer flex-shrink-0"
            whileHover={{ scale: 1.05 }}
            onClick={() => scrollToSection("hero")}
          >
            CT
          </motion.div>

          {/* Navigation Items - Always visible but responsive */}
          <div className="flex items-center space-x-1 sm:space-x-2 lg:space-x-4 flex-shrink-0">
            {navItems.map((item) => (
              <motion.button
                key={item.id}
                className={`px-2 sm:px-3 lg:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                  currentSection === item.id
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 shadow-lg"
                    : "text-white/70 hover:text-white hover:bg-white/10"
                }`}
                onClick={() => scrollToSection(item.id)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {item.label}
              </motion.button>
            ))}
          </div>

          {/* Resume Download - Hidden on very small screens */}
          <motion.button
            onClick={downloadResume}
            className="hidden sm:flex items-center px-2 lg:px-3 py-1 lg:py-1.5 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 rounded-full text-cyan-300 text-xs font-medium hover:bg-gradient-to-r hover:from-cyan-500/30 hover:to-purple-500/30 transition-all duration-300 flex-shrink-0"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <span className="hidden lg:inline">Resume</span>
            <span className="lg:hidden">CV</span>
          </motion.button>

          {/* Theme Toggle */}
          <div className="flex-shrink-0">
            <ThemeToggle />
          </div>

          {/* Mobile Menu Button - Only for very small screens */}
          <button className="sm:hidden text-white/70 hover:text-white flex-shrink-0" onClick={() => setIsOpen(!isOpen)}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Mobile Menu - Only for very small screens */}
        {isOpen && (
          <motion.div
            className="sm:hidden mt-4 pt-4 border-t border-white/20"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            {navItems.map((item) => (
              <button
                key={item.id}
                className="block w-full text-left px-4 py-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg"
                onClick={() => scrollToSection(item.id)}
              >
                {item.label}
              </button>
            ))}
            <button
              className="block w-full text-left px-4 py-2 text-cyan-300 hover:text-cyan-200 hover:bg-white/10 rounded-lg mt-2"
              onClick={downloadResume}
            >
              Download Resume
            </button>
          </motion.div>
        )}
      </div>
    </motion.nav>
  )
}
