"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

export function ThemeToggle() {
  const [isDark, setIsDark] = useState(false)

  useEffect(() => {
    const theme = localStorage.getItem("theme")
    const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches

    if (theme === "dark" || (!theme && systemPrefersDark)) {
      setIsDark(true)
      document.documentElement.classList.add("dark")
    }
  }, [])

  const toggleTheme = () => {
    const newTheme = !isDark
    setIsDark(newTheme)

    if (newTheme) {
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme", "dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme", "light")
    }
  }

  return (
    <motion.button
      onClick={toggleTheme}
      className="relative w-12 h-6 bg-white/20 rounded-full p-1 backdrop-blur-sm border border-white/20"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <motion.div
        className="w-4 h-4 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full shadow-lg"
        animate={{
          x: isDark ? 20 : 0,
        }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
      />

      {/* Icons */}
      <div className="absolute inset-0 flex items-center justify-between px-1 pointer-events-none">
        <motion.div animate={{ opacity: isDark ? 0 : 1, scale: isDark ? 0.5 : 1 }} transition={{ duration: 0.2 }}>
          ☀️
        </motion.div>
        <motion.div animate={{ opacity: isDark ? 1 : 0, scale: isDark ? 1 : 0.5 }} transition={{ duration: 0.2 }}>
          🌙
        </motion.div>
      </div>
    </motion.button>
  )
}
