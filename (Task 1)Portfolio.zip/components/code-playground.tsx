"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"

interface CodePlaygroundProps {
  code: string
  title: string
  onClose: () => void
}

export function CodePlayground({ code, title, onClose }: CodePlaygroundProps) {
  const [activeTab, setActiveTab] = useState("code")
  const [editorCode, setEditorCode] = useState(code)
  const [consoleOutput, setConsoleOutput] = useState<Array<{ type: string; content: string }>>([])
  const [isRunning, setIsRunning] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const consoleEndRef = useRef<HTMLDivElement>(null)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  useEffect(() => {
    setEditorCode(code)
    setConsoleOutput([])
    setError(null)
  }, [code])

  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [consoleOutput])

  const handleCodeChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setEditorCode(e.target.value)
    setError(null)
  }

  const runCode = async () => {
    setIsRunning(true)
    setConsoleOutput([])
    setError(null)

    try {
      // Create a safe execution environment using an iframe
      if (iframeRef.current) {
        const iframe = iframeRef.current
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document

        if (iframeDoc) {
          // Reset the iframe
          iframeDoc.open()

          // Create a custom console implementation that captures logs
          const consoleCapture = `
            <script>
              const originalConsole = window.console;
              window.console = {
                log: function(...args) {
                  originalConsole.log(...args);
                  window.parent.postMessage({
                    type: 'log',
                    content: args.map(arg => {
                      try {
                        return typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg);
                      } catch (e) {
                        return String(arg);
                      }
                    }).join(' ')
                  }, '*');
                },
                error: function(...args) {
                  originalConsole.error(...args);
                  window.parent.postMessage({
                    type: 'error',
                    content: args.map(arg => {
                      try {
                        return typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg);
                      } catch (e) {
                        return String(arg);
                      }
                    }).join(' ')
                  }, '*');
                },
                warn: function(...args) {
                  originalConsole.warn(...args);
                  window.parent.postMessage({
                    type: 'warn',
                    content: args.map(arg => {
                      try {
                        return typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg);
                      } catch (e) {
                        return String(arg);
                      }
                    }).join(' ')
                  }, '*');
                },
                info: function(...args) {
                  originalConsole.info(...args);
                  window.parent.postMessage({
                    type: 'info',
                    content: args.map(arg => {
                      try {
                        return typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg);
                      } catch (e) {
                        return String(arg);
                      }
                    }).join(' ')
                  }, '*');
                }
              };

              // Capture errors
              window.onerror = function(message, source, lineno, colno, error) {
                window.parent.postMessage({
                  type: 'error',
                  content: message
                }, '*');
                return true;
              };
            </script>
          `

          // Write the HTML with the script and console capture
          iframeDoc.write(`
            <!DOCTYPE html>
            <html>
              <head>
                <title>Code Execution</title>
                ${consoleCapture}
              </head>
              <body>
                <script>
                  try {
                    ${editorCode}
                  } catch (error) {
                    console.error(error.message);
                  }
                </script>
              </body>
            </html>
          `)
          iframeDoc.close()
        }
      }

      // Add initial message
      setConsoleOutput([{ type: "info", content: `Running ${title} code...` }])

      // Listen for messages from the iframe
      const handleMessage = (event: MessageEvent) => {
        if (event.data && event.data.type) {
          setConsoleOutput((prev) => [
            ...prev,
            {
              type: event.data.type,
              content: event.data.content,
            },
          ])
        }
      }

      window.addEventListener("message", handleMessage)

      // Clean up
      setTimeout(() => {
        setIsRunning(false)
        window.removeEventListener("message", handleMessage)
      }, 100)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred while running the code")
      setIsRunning(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        className="bg-white/10 backdrop-blur-md rounded-3xl border border-white/20 max-w-5xl w-full h-[80vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-white/20">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">{title} - Code Playground</h2>
            <button onClick={onClose} className="text-white/70 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Tabs */}
          <div className="flex space-x-4 mt-4">
            {["code", "preview", "console"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                  activeTab === tab
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/30"
                    : "text-white/70 hover:text-white hover:bg-white/10"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 h-[calc(80vh-180px)] overflow-hidden">
          {activeTab === "code" && (
            <div className="h-full flex flex-col">
              <div className="flex-1 p-4 overflow-auto">
                <textarea
                  value={editorCode}
                  onChange={handleCodeChange}
                  className="w-full h-full bg-black/30 rounded-xl p-4 font-mono text-sm text-green-300 resize-none focus:outline-none focus:ring-1 focus:ring-cyan-500/50"
                  spellCheck="false"
                />
              </div>
              <div className="p-4 border-t border-white/20 flex justify-between items-center">
                <div>{error && <p className="text-red-400 text-sm">{error}</p>}</div>
                <motion.button
                  onClick={runCode}
                  disabled={isRunning}
                  className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-lg text-white font-semibold shadow-lg hover:shadow-cyan-500/25 transition-all duration-300 disabled:opacity-50"
                  whileHover={{ scale: isRunning ? 1 : 1.05 }}
                  whileTap={{ scale: isRunning ? 1 : 0.95 }}
                >
                  {isRunning ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                      Running...
                    </div>
                  ) : (
                    "Run Code"
                  )}
                </motion.button>
              </div>
            </div>
          )}

          {activeTab === "preview" && (
            <div className="h-full p-4 overflow-auto">
              <div className="bg-white/5 rounded-xl p-4 h-full">
                <iframe
                  ref={iframeRef}
                  title="Code Preview"
                  className="w-full h-full border-0 rounded-lg bg-white"
                  sandbox="allow-scripts"
                />
              </div>
            </div>
          )}

          {activeTab === "console" && (
            <div className="h-full p-4 overflow-auto bg-black/40 font-mono text-sm">
              {consoleOutput.length === 0 ? (
                <div className="text-white/50 p-4 text-center">
                  <p>Console output will appear here after running the code.</p>
                  <p className="mt-2">Click "Run Code" to execute.</p>
                </div>
              ) : (
                <div className="space-y-2 p-2">
                  {consoleOutput.map((output, index) => (
                    <div key={index} className={`p-2 rounded ${getConsoleItemClass(output.type)}`}>
                      <span className="mr-2 font-bold">{getConsolePrefix(output.type)}</span>
                      <span className="font-mono whitespace-pre-wrap">{output.content}</span>
                    </div>
                  ))}
                  <div ref={consoleEndRef} />
                </div>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  )
}

function getConsoleItemClass(type: string): string {
  switch (type) {
    case "error":
      return "bg-red-900/30 text-red-300 border-l-4 border-red-500"
    case "warn":
      return "bg-yellow-900/30 text-yellow-300 border-l-4 border-yellow-500"
    case "info":
      return "bg-blue-900/30 text-blue-300 border-l-4 border-blue-500"
    default:
      return "bg-green-900/30 text-green-300 border-l-4 border-green-500"
  }
}

function getConsolePrefix(type: string): string {
  switch (type) {
    case "error":
      return "❌ Error:"
    case "warn":
      return "⚠️ Warning:"
    case "info":
      return "ℹ️ Info:"
    default:
      return "✅ Log:"
  }
}
