"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface EasterEggProps {
  isActivated: boolean
  onActivate: () => void
}

export function EasterEgg({ isActivated, onActivate }: EasterEggProps) {
  const [konamiSequence] = useState([
    "ArrowUp",
    "ArrowUp",
    "ArrowDown",
    "ArrowDown",
    "ArrowLeft",
    "ArrowRight",
    "ArrowLeft",
    "ArrowRight",
    "KeyB",
    "KeyA",
  ])
  const [userSequence, setUserSequence] = useState<string[]>([])

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      setUserSequence((prev) => {
        const newSequence = [...prev, event.code]

        // Keep only the last 10 keys
        if (newSequence.length > 10) {
          newSequence.shift()
        }

        // Check if sequence matches Konami code
        if (newSequence.length === 10 && newSequence.every((key, index) => key === konamiSequence[index])) {
          onActivate()
          return []
        }

        return newSequence
      })
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [konamiSequence, onActivate])

  return (
    <AnimatePresence>
      {isActivated && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center"
          onClick={() => window.location.reload()}
        >
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: "spring", duration: 1 }}
            className="text-center"
          >
            <div className="text-8xl mb-8">🎉</div>
            <h2 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-4">
              Easter Egg Activated!
            </h2>
            <p className="text-white/80 text-xl mb-8">You found the secret! Welcome to the hidden dimension.</p>
            <div className="space-y-4">
              <p className="text-cyan-300">🎮 Konami Code Master Detected</p>
              <p className="text-purple-300">✨ Achievement Unlocked: Secret Explorer</p>
              <p className="text-pink-300">🚀 You're now part of the elite club!</p>
            </div>
            <motion.button
              className="mt-8 px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full text-white font-semibold"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.location.reload()}
            >
              Return to Reality
            </motion.button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
