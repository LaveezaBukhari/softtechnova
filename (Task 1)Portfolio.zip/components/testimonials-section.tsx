"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

export function TestimonialsSection() {
  const [activeTestimonial, setActiveTestimonial] = useState(0)

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Product Manager at TechCorp",
      company: "TechCorp",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Working with Sardar was an absolute pleasure. His ability to bridge the gap between design and development is remarkable. He delivered a stunning, functional product that exceeded our expectations.",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "CTO at StartupXYZ",
      company: "StartupXYZ",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Sardar's technical expertise and creative vision helped us build a product that our users love. His attention to detail and commitment to quality is unmatched.",
      rating: 5,
    },
    {
      name: "Emily Rodriguez",
      role: "Design Director at CreativeStudio",
      company: "CreativeStudio",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "An exceptional creative technologist who understands both the technical and aesthetic aspects of digital products. Highly recommended for any complex project.",
      rating: 5,
    },
    {
      name: "David Kim",
      role: "Lead Developer at InnovateLab",
      company: "InnovateLab",
      image: "/placeholder.svg?height=80&width=80",
      content:
        "Sardar's code quality and architectural decisions are top-notch. He's the kind of developer every team needs - skilled, reliable, and innovative.",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              Client Testimonials
            </span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            What clients and colleagues say about working with me.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Testimonial Navigation */}
          <div className="space-y-4">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                className={`p-4 rounded-2xl cursor-pointer transition-all duration-300 ${
                  activeTestimonial === index
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30"
                    : "bg-white/5 border border-white/10 hover:bg-white/10"
                }`}
                onClick={() => setActiveTestimonial(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-center space-x-4">
                  <img
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="text-white font-semibold">{testimonial.name}</h4>
                    <p className="text-white/60 text-sm">{testimonial.role}</p>
                    <p className="text-cyan-300 text-xs">{testimonial.company}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Active Testimonial */}
          <div className="lg:sticky lg:top-24">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTestimonial}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20"
              >
                <div className="mb-6">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(testimonials[activeTestimonial].rating)].map((_, i) => (
                      <span key={i} className="text-yellow-400 text-xl">
                        ⭐
                      </span>
                    ))}
                  </div>
                  <blockquote className="text-white/90 text-lg leading-relaxed mb-6">
                    "{testimonials[activeTestimonial].content}"
                  </blockquote>
                </div>

                <div className="flex items-center space-x-4">
                  <img
                    src={testimonials[activeTestimonial].image || "/placeholder.svg"}
                    alt={testimonials[activeTestimonial].name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="text-white font-bold text-lg">{testimonials[activeTestimonial].name}</h4>
                    <p className="text-white/70">{testimonials[activeTestimonial].role}</p>
                    <p className="text-cyan-300 text-sm">{testimonials[activeTestimonial].company}</p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20 grid md:grid-cols-4 gap-8"
        >
          {[
            { number: "50+", label: "Projects Completed" },
            { number: "25+", label: "Happy Clients" },
            { number: "3+", label: "Years Experience" },
            { number: "100%", label: "Client Satisfaction" },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-2">
                {stat.number}
              </div>
              <div className="text-white/70">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}
