"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

export function AboutSection() {
  const [activeTimeline, setActiveTimeline] = useState(0)

  const timelineData = [
    {
      year: "2024",
      title: "Software Developer",
      company: "Freelance",
      description:
        "Working on diverse projects including web applications, development tools, and open-source contributions.",
      skills: ["JavaScript", "HTML", "CSS", "Python", "React"],
    },
    {
      year: "2023",
      title: "Full-Stack Developer",
      company: "Personal Projects",
      description:
        "Developed various web applications and tools, focusing on user experience and clean code practices.",
      skills: ["JavaScript", "Node.js", "CSS", "HTML", "Git"],
    },
    {
      year: "2022",
      title: "Frontend Developer",
      company: "Learning & Development",
      description: "Focused on mastering modern web technologies and building responsive, interactive user interfaces.",
      skills: ["HTML", "CSS", "JavaScript", "Responsive Design"],
    },
    {
      year: "2021",
      title: "Computer Science Student",
      company: "University",
      description:
        "Studying computer science fundamentals and exploring various programming languages and technologies.",
      skills: ["Python", "Algorithms", "Data Structures", "Problem Solving"],
    },
  ]

  return (
    <div className="min-h-screen py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              My Journey
            </span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Hi, I'm <span className="text-cyan-400 font-semibold">Laveeza Bukhari</span>, a passionate developer with
            expertise in modern web technologies. I love creating innovative solutions that bridge functionality and
            user experience.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Timeline Navigation */}
          <div className="space-y-4">
            {timelineData.map((item, index) => (
              <motion.div
                key={index}
                className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 ${
                  activeTimeline === index
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 shadow-lg"
                    : "bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
                }`}
                onClick={() => setActiveTimeline(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl font-bold text-cyan-400">{item.year}</span>
                  <div className={`w-3 h-3 rounded-full ${activeTimeline === index ? "bg-cyan-400" : "bg-white/30"}`} />
                </div>
                <h3 className="text-xl font-semibold text-white mb-1">{item.title}</h3>
                <p className="text-purple-300">{item.company}</p>
              </motion.div>
            ))}
          </div>

          {/* Timeline Content */}
          <div className="lg:sticky lg:top-24">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTimeline}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.5 }}
                className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20"
              >
                <div className="mb-6">
                  <span className="text-3xl font-bold text-cyan-400">{timelineData[activeTimeline].year}</span>
                  <h3 className="text-2xl font-bold text-white mt-2">{timelineData[activeTimeline].title}</h3>
                  <p className="text-purple-300 text-lg">{timelineData[activeTimeline].company}</p>
                </div>

                <p className="text-white/80 text-lg leading-relaxed mb-6">{timelineData[activeTimeline].description}</p>

                <div className="space-y-3">
                  <h4 className="text-white font-semibold">Key Skills & Technologies:</h4>
                  <div className="flex flex-wrap gap-2">
                    {timelineData[activeTimeline].skills.map((skill, skillIndex) => (
                      <motion.span
                        key={skillIndex}
                        className="px-3 py-1 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full text-sm text-cyan-300 border border-cyan-500/30"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: skillIndex * 0.1 }}
                      >
                        {skill}
                      </motion.span>
                    ))}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Skills Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <h3 className="text-3xl font-bold text-center mb-12 text-white">Core Competencies</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "Frontend Development",
                skills: ["JavaScript", "React", "HTML5", "CSS3", "Responsive Design"],
              },
              { title: "Backend & Tools", skills: ["Python", "Node.js", "Git", "Terminal", "Development Tools"] },
              {
                title: "Problem Solving",
                skills: ["Algorithm Design", "Code Optimization", "Debugging", "Testing", "Documentation"],
              },
            ].map((category, index) => (
              <motion.div
                key={index}
                className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
                whileHover={{ scale: 1.05, backgroundColor: "rgba(255, 255, 255, 0.1)" }}
                transition={{ duration: 0.3 }}
              >
                <h4 className="text-xl font-semibold text-cyan-400 mb-4">{category.title}</h4>
                <ul className="space-y-2">
                  {category.skills.map((skill, skillIndex) => (
                    <li key={skillIndex} className="text-white/70 flex items-center">
                      <div className="w-2 h-2 bg-purple-400 rounded-full mr-3" />
                      {skill}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
