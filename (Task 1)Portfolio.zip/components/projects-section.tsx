"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CodePlayground } from "./code-playground"
import { getLanguageColor, type GitHubRepo } from "@/lib/github-api"

export function ProjectsSection() {
  const [selectedProject, setSelectedProject] = useState(0)
  const [showPlayground, setShowPlayground] = useState(false)
  const [projects, setProjects] = useState<GitHubRepo[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTech, setSelectedTech] = useState<string | null>(null)

  useEffect(() => {
    fetchProjects()
  }, [])

  const fetchProjects = async () => {
    try {
      const response = await fetch("/api/github/repos")
      if (!response.ok) {
        throw new Error("Failed to fetch repositories")
      }
      const repos = await response.json()
      setProjects(repos)
      setError(null)
    } catch (err) {
      console.error("Error fetching projects:", err)
      setError("Failed to load projects")
    } finally {
      setLoading(false)
    }
  }

  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (project.description && project.description.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesTech = !selectedTech || project.language === selectedTech
    return matchesSearch && matchesTech
  })

  const technologies = [...new Set(projects.map((p) => p.language).filter(Boolean))]

  const generateDemoCode = (repo: GitHubRepo) => {
    const language = repo.language?.toLowerCase() || "javascript"

    if (language === "html") {
      return `<!-- ${repo.name} - Interactive HTML Demo -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${repo.name}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 800px;
            text-align: center;
            padding: 2rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        h1 { font-size: 3rem; margin-bottom: 1rem; }
        p { font-size: 1.2rem; margin-bottom: 2rem; opacity: 0.9; }
        .btn {
            background: linear-gradient(45deg, #00d4ff, #8b5cf6);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: bold;
            transition: transform 0.3s ease;
            margin: 0 10px;
        }
        .btn:hover { transform: translateY(-3px); }
        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        .feature {
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .feature:hover { transform: scale(1.05); }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 ${repo.name}</h1>
        <p>${repo.description || "A modern web application built with HTML, CSS, and JavaScript"}</p>
        
        <button class="btn" onclick="showAlert()">Get Started</button>
        <button class="btn" onclick="toggleTheme()">Toggle Theme</button>
        
        <div class="feature-grid">
            <div class="feature">
                <h3>🎨 Modern Design</h3>
                <p>Beautiful, responsive interface</p>
            </div>
            <div class="feature">
                <h3>⚡ Fast Performance</h3>
                <p>Optimized for speed</p>
            </div>
            <div class="feature">
                <h3>📱 Mobile Ready</h3>
                <p>Works on all devices</p>
            </div>
        </div>
    </div>

    <script>
        function showAlert() {
            alert('Welcome to ${repo.name}! This is an interactive demo.');
        }
        
        function toggleTheme() {
            const body = document.body;
            const isDark = body.style.background.includes('764ba2');
            body.style.background = isDark 
                ? 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)'
                : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        }
        
        console.log('${repo.name} loaded successfully! 🎉');
        console.log('Repository: ${repo.html_url}');
    </script>
</body>
</html>`
    }

    if (language === "typescript") {
      return `// ${repo.name} - Advanced TypeScript Demo
interface ProjectConfig {
  name: string;
  description: string;
  version: string;
  features: Feature[];
  metadata: ProjectMetadata;
}

interface Feature {
  id: string;
  name: string;
  enabled: boolean;
  priority: 'high' | 'medium' | 'low';
}

interface ProjectMetadata {
  author: string;
  createdAt: Date;
  lastModified: Date;
  tags: string[];
  stats: ProjectStats;
}

interface ProjectStats {
  stars: number;
  forks: number;
  downloads: number;
  contributors: number;
}

class ProjectManager {
  private config: ProjectConfig;
  private eventListeners: Map<string, Function[]> = new Map();

  constructor(config: ProjectConfig) {
    this.config = config;
    this.init();
  }

  private init(): void {
    console.log(\`🚀 Initializing \${this.config.name}...\`);
    this.setupEventListeners();
    this.displayProjectInfo();
    this.runFeatureChecks();
  }

  private setupEventListeners(): void {
    this.on('feature:toggle', (feature: Feature) => {
      console.log(\`🔄 Feature '\${feature.name}' \${feature.enabled ? 'enabled' : 'disabled'}\`);
    });

    this.on('stats:update', (stats: ProjectStats) => {
      console.log(\`📊 Stats updated:\`, stats);
    });
  }

  public on(event: string, callback: Function): void {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event)!.push(callback);
  }

  private emit(event: string, data: any): void {
    const listeners = this.eventListeners.get(event) || [];
    listeners.forEach(callback => callback(data));
  }

  public toggleFeature(featureId: string): boolean {
    const feature = this.config.features.find(f => f.id === featureId);
    if (feature) {
      feature.enabled = !feature.enabled;
      this.emit('feature:toggle', feature);
      return true;
    }
    return false;
  }

  public updateStats(newStats: Partial<ProjectStats>): void {
    this.config.metadata.stats = { ...this.config.metadata.stats, ...newStats };
    this.emit('stats:update', this.config.metadata.stats);
  }

  private displayProjectInfo(): void {
    console.log(\`📝 Project: \${this.config.name}\`);
    console.log(\`📄 Description: \${this.config.description}\`);
    console.log(\`🏷️ Version: \${this.config.version}\`);
    console.log(\`👤 Author: \${this.config.metadata.author}\`);
    console.log(\`🏷️ Tags: \${this.config.metadata.tags.join(', ')}\`);
  }

  private runFeatureChecks(): void {
    console.log(\`\\n🔍 Running feature checks...\`);
    this.config.features.forEach(feature => {
      const status = feature.enabled ? '✅' : '❌';
      console.log(\`\${status} \${feature.name} (Priority: \${feature.priority})\`);
    });
  }

  public getProjectSummary(): ProjectConfig {
    return { ...this.config };
  }
}

// Initialize the project
const projectConfig: ProjectConfig = {
  name: "${repo.name}",
  description: "${repo.description || "A TypeScript project with advanced features"}",
  version: "1.0.0",
  features: [
    { id: "auth", name: "Authentication", enabled: true, priority: "high" },
    { id: "api", name: "REST API", enabled: true, priority: "high" },
    { id: "ui", name: "Modern UI", enabled: true, priority: "medium" },
    { id: "tests", name: "Unit Tests", enabled: false, priority: "medium" },
    { id: "docs", name: "Documentation", enabled: true, priority: "low" }
  ],
  metadata: {
    author: "Sardar Muhammad Ahsan Khan",
    createdAt: new Date("${repo.created_at}"),
    lastModified: new Date("${repo.updated_at}"),
    tags: ["typescript", "modern", "scalable"],
    stats: {
      stars: ${repo.stargazers_count},
      forks: ${repo.forks_count},
      downloads: 1250,
      contributors: 3
    }
  }
};

const project = new ProjectManager(projectConfig);

// Demonstrate functionality
setTimeout(() => {
  console.log("\\n🎮 Demonstrating features...");
  project.toggleFeature("tests");
  project.updateStats({ downloads: 1500, contributors: 5 });
}, 2000);

setTimeout(() => {
  console.log("\\n📋 Final Project Summary:");
  console.log(project.getProjectSummary());
}, 4000);`
    }

    if (language === "python") {
      return `# ${repo.name} - Advanced Python Demo
import datetime
import json
from typing import List, Dict, Optional, Union
from dataclasses import dataclass, asdict
from enum import Enum

class Priority(Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class Status(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    MAINTENANCE = "maintenance"

@dataclass
class ProjectStats:
    stars: int
    forks: int
    issues: int
    contributors: int
    last_commit: datetime.datetime

@dataclass
class Feature:
    name: str
    description: str
    enabled: bool
    priority: Priority
    dependencies: List[str] = None

    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []

class ProjectAnalyzer {
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.created_at = datetime.datetime.now()
        self.status = Status.ACTIVE
        self.features: List[Feature] = []
        self.stats = ProjectStats(
            stars=${repo.stargazers_count},
            forks=${repo.forks_count},
            issues=0,
            contributors=1,
            last_commit=datetime.datetime.fromisoformat("${repo.updated_at}".replace('Z', '+00:00'))
        )
        self._setup_default_features()

    def _setup_default_features(self) -> None:
        """Initialize default project features"""
        default_features = [
            Feature("Authentication", "User login and registration", True, Priority.HIGH),
            Feature("API Integration", "RESTful API endpoints", True, Priority.HIGH, ["Authentication"]),
            Feature("Database", "Data persistence layer", True, Priority.HIGH),
            Feature("Testing", "Unit and integration tests", False, Priority.MEDIUM, ["Database"]),
            Feature("Documentation", "Comprehensive docs", True, Priority.LOW),
            Feature("Monitoring", "Application monitoring", False, Priority.MEDIUM, ["API Integration"])
        ]
        self.features.extend(default_features)

    def add_feature(self, feature: Feature) -> None:
        """Add a new feature to the project"""
        self.features.append(feature)
        print(f"✅ Added feature: {feature.name}")

    def enable_feature(self, feature_name: str) -> bool:
        """Enable a specific feature"""
        for feature in self.features:
            if feature.name == feature_name:
                if self._check_dependencies(feature):
                    feature.enabled = True
                    print(f"🟢 Enabled: {feature_name}")
                    return True
                else:
                    print(f"❌ Cannot enable {feature_name}: missing dependencies")
                    return False
        print(f"❌ Feature not found: {feature_name}")
        return False

    def _check_dependencies(self, feature: Feature) -> bool:
        """Check if all dependencies are enabled"""
        for dep_name in feature.dependencies:
            dep_feature = next((f for f in self.features if f.name == dep_name), None)
            if not dep_feature or not dep_feature.enabled:
                return False
        return True

    def get_enabled_features(self) -> List[Feature]:
        """Get all enabled features"""
        return [f for f in self.features if f.enabled]

    def analyze_project_health(self) -> Dict[str, Union[str, int, float]]:
        """Analyze overall project health"""
        enabled_features = len(self.get_enabled_features())
        total_features = len(self.features)
        feature_completion = (enabled_features / total_features) * 100

        high_priority_enabled = len([f for f in self.features 
                                   if f.enabled and f.priority == Priority.HIGH])
        high_priority_total = len([f for f in self.features 
                                 if f.priority == Priority.HIGH])

        days_since_update = (datetime.datetime.now() - self.stats.last_commit.replace(tzinfo=None)).days

        health_score = (
            (feature_completion * 0.4) +
            ((high_priority_enabled / max(high_priority_total, 1)) * 100 * 0.4) +
            (max(0, 100 - days_since_update) * 0.2)
        )

        return {
            "health_score": round(health_score, 2),
            "feature_completion": round(feature_completion, 2),
            "enabled_features": enabled_features,
            "total_features": total_features,
            "days_since_update": days_since_update,
            "status": self.status.value
        }

    def generate_report(self) -> str:
        """Generate a comprehensive project report"""
        health = self.analyze_project_health()
        
        report = f"""
🐍 PROJECT ANALYSIS REPORT
{'=' * 50}
📊 Project: {self.name}
📝 Description: {self.description}
📅 Created: {self.created_at.strftime('%Y-%m-%d %H:%M:%S')}
🔄 Status: {self.status.value.upper()}

📈 HEALTH METRICS
{'=' * 30}
🎯 Health Score: {health['health_score']}%
✅ Feature Completion: {health['feature_completion']}%
🔧 Enabled Features: {health['enabled_features']}/{health['total_features']}
📅 Days Since Update: {health['days_since_update']}

📊 REPOSITORY STATS
{'=' * 30}
⭐ Stars: {self.stats.stars}
🍴 Forks: {self.stats.forks}
👥 Contributors: {self.stats.contributors}
🐛 Issues: {self.stats.issues}

🔧 FEATURES STATUS
{'=' * 30}"""

        for feature in self.features:
            status = "🟢" if feature.enabled else "🔴"
            priority_icon = {"high": "🔥", "medium": "⚡", "low": "📝"}[feature.priority.value]
            deps = f" (Deps: {', '.join(feature.dependencies)})" if feature.dependencies else ""
            report += f"\\n{status} {priority_icon} {feature.name}{deps}"

        return report

    def export_config(self) -> str:
        """Export project configuration as JSON"""
        config = {
            "name": self.name,
            "description": self.description,
            "created_at": self.created_at.isoformat(),
            "status": self.status.value,
            "features": [asdict(feature) for feature in self.features],
            "stats": asdict(self.stats)
        }
        return json.dumps(config, indent=2, default=str)

# Initialize and demonstrate the project analyzer
analyzer = ProjectAnalyzer(
    "${repo.name}",
    "${repo.description || "A comprehensive Python project with advanced features"}"
)

print(f"🚀 Initializing {analyzer.name}...")
print(f"📝 {analyzer.description}")

# Demonstrate feature management
print("\\n🔧 Managing features...")
analyzer.enable_feature("Testing")
analyzer.enable_feature("Monitoring")

# Add a custom feature
custom_feature = Feature(
    "Machine Learning",
    "AI-powered analytics",
    False,
    Priority.MEDIUM,
    ["Database", "API Integration"]
)
analyzer.add_feature(custom_feature)
analyzer.enable_feature("Machine Learning")

# Generate and display report
print(analyzer.generate_report())

# Show health analysis
health = analyzer.analyze_project_health()
print(f"\\n🎯 Overall Health Score: {health['health_score']}%")

print("\\n📋 Project configuration exported!")
print("🎉 Analysis complete!")`
    }

    // Enhanced JavaScript with more interactive features
    return `// ${repo.name} - Interactive JavaScript Demo
class AdvancedProjectShowcase {
  constructor(projectData) {
    this.project = projectData;
    this.stats = {
      views: 0,
      likes: 0,
      shares: 0,
      interactions: 0
    };
    this.features = new Map();
    this.eventLog = [];
    this.init();
  }

  init() {
    this.displayWelcome();
    this.setupFeatures();
    this.startInteractiveDemo();
    this.setupEventListeners();
  }

  displayWelcome() {
    console.log(\`🎉 Welcome to \${this.project.name}!\`);
    console.log(\`📝 \${this.project.description}\`);
    console.log(\`⭐ Stars: \${this.project.stars} | 🍴 Forks: \${this.project.forks}\`);
    console.log(\`💻 Built with: \${this.project.language}\`);
    console.log(\`🔗 Repository: \${this.project.url}\`);
    this.logEvent('project_initialized');
  }

  setupFeatures() {
    const projectFeatures = [
      { name: 'Authentication', enabled: true, priority: 'high' },
      { name: 'Real-time Updates', enabled: true, priority: 'medium' },
      { name: 'Data Visualization', enabled: false, priority: 'medium' },
      { name: 'Mobile Support', enabled: true, priority: 'high' },
      { name: 'API Integration', enabled: true, priority: 'high' },
      { name: 'Testing Suite', enabled: false, priority: 'low' }
    ];

    projectFeatures.forEach(feature => {
      this.features.set(feature.name, feature);
    });

    console.log('\\n🔧 Project Features:');
    this.displayFeatures();
  }

  displayFeatures() {
    this.features.forEach((feature, name) => {
      const status = feature.enabled ? '✅' : '❌';
      const priority = this.getPriorityIcon(feature.priority);
      console.log(\`\${status} \${priority} \${name}\`);
    });
  }

  getPriorityIcon(priority) {
    const icons = { high: '🔥', medium: '⚡', low: '📝' };
    return icons[priority] || '📌';
  }

  toggleFeature(featureName) {
    if (this.features.has(featureName)) {
      const feature = this.features.get(featureName);
      feature.enabled = !feature.enabled;
      const status = feature.enabled ? 'enabled' : 'disabled';
      console.log(\`🔄 Feature '\${featureName}' \${status}\`);
      this.logEvent('feature_toggle', { feature: featureName, enabled: feature.enabled });
      return true;
    }
    console.log(\`❌ Feature '\${featureName}' not found\`);
    return false;
  }

  startInteractiveDemo() {
    console.log('\\n🎮 Starting interactive demo...');
    
    // Simulate user interactions
    setTimeout(() => this.simulateUserAction('view'), 1000);
    setTimeout(() => this.simulateUserAction('like'), 2500);
    setTimeout(() => this.simulateUserAction('share'), 4000);
    setTimeout(() => this.toggleFeature('Data Visualization'), 5500);
    setTimeout(() => this.toggleFeature('Testing Suite'), 7000);
    setTimeout(() => this.generateAnalytics(), 8500);
  }

  simulateUserAction(action) {
    this.stats[action + 's']++;
    this.stats.interactions++;
    
    const messages = {
      view: \`👀 Someone viewed \${this.project.name}\`,
      like: \`❤️ Someone liked \${this.project.name}\`,
      share: \`🔄 Someone shared \${this.project.name}\`
    };
    
    console.log(messages[action]);
    this.logEvent('user_action', { action, timestamp: new Date().toISOString() });
  }

  setupEventListeners() {
    // Simulate real-time events
    setInterval(() => {
      if (Math.random() > 0.7) {
        const actions = ['view', 'like', 'share'];
        const randomAction = actions[Math.floor(Math.random() * actions.length)];
        this.simulateUserAction(randomAction);
      }
    }, 3000);

    // Display stats periodically
    setInterval(() => {
      this.displayCurrentStats();
    }, 10000);
  }

  displayCurrentStats() {
    console.log(\`\\n📊 Live Stats - Views: \${this.stats.views}, Likes: \${this.stats.likes}, Shares: \${this.stats.shares}, Total Interactions: \${this.stats.interactions}\`);
  }

  logEvent(eventType, data = {}) {
    this.eventLog.push({
      type: eventType,
      timestamp: new Date().toISOString(),
      data
    });
  }

  generateAnalytics() {
    console.log('\\n📈 Generating Analytics Report...');
    
    const enabledFeatures = Array.from(this.features.values()).filter(f => f.enabled);
    const featureCompletion = (enabledFeatures.length / this.features.size) * 100;
    
    const analytics = {
      project: this.project.name,
      engagement: {
        totalInteractions: this.stats.interactions,
        viewToLikeRatio: this.stats.views > 0 ? (this.stats.likes / this.stats.views * 100).toFixed(2) + '%' : '0%',
        shareRate: this.stats.shares > 0 ? (this.stats.shares / this.stats.views * 100).toFixed(2) + '%' : '0%'
      },
      features: {
        total: this.features.size,
        enabled: enabledFeatures.length,
        completion: featureCompletion.toFixed(2) + '%'
      },
      repository: {
        stars: this.project.stars,
        forks: this.project.forks,
        language: this.project.language
      },
      events: this.eventLog.length
    };

    console.log('📋 Analytics Report:');
    console.log(JSON.stringify(analytics, null, 2));
    
    return analytics;
  }

  getProjectSummary() {
    return {
      ...this.project,
      stats: this.stats,
      features: Object.fromEntries(this.features),
      analytics: this.generateAnalytics(),
      lastUpdated: new Date().toISOString()
    };
  }
}

// Initialize the enhanced project showcase
const projectData = {
  name: "${repo.name}",
  description: "${repo.description || "An interactive JavaScript project with advanced features"}",
  language: "${repo.language}",
  stars: ${repo.stargazers_count},
  forks: ${repo.forks_count},
  url: "${repo.html_url}"
};

const showcase = new AdvancedProjectShowcase(projectData);

// Demonstrate advanced features
setTimeout(() => {
  console.log('\\n🎯 Testing feature toggles...');
  showcase.toggleFeature('Data Visualization');
  showcase.toggleFeature('Testing Suite');
}, 6000);

setTimeout(() => {
  console.log('\\n📊 Final Project Summary:');
  const summary = showcase.getProjectSummary();
  console.log('Project successfully analyzed! 🎉');
}, 12000);`
  }

  if (loading) {
    return (
      <div className="min-h-screen py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
                GitHub Projects
              </span>
            </h2>
            <p className="text-xl text-white/60 max-w-2xl mx-auto">Loading projects from GitHub...</p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
                  <div className="animate-pulse">
                    <div className="h-6 bg-white/20 rounded mb-2" />
                    <div className="h-4 bg-white/10 rounded mb-4" />
                    <div className="h-16 bg-white/10 rounded" />
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20">
              <div className="animate-pulse">
                <div className="h-64 bg-white/10 rounded-xl mb-6" />
                <div className="h-8 bg-white/20 rounded mb-4" />
                <div className="h-20 bg-white/10 rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (error || projects.length === 0) {
    return (
      <div className="min-h-screen py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              GitHub Projects
            </span>
          </h2>
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-12 border border-white/20">
            <div className="text-6xl mb-4">📁</div>
            <h3 className="text-2xl font-bold text-white mb-4">
              {error ? "Failed to Load Projects" : "No Projects Found"}
            </h3>
            <p className="text-white/60 mb-6">{error || "No public repositories found on GitHub."}</p>
            <motion.button
              onClick={fetchProjects}
              className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-xl text-white font-semibold"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Try Again
            </motion.button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
              GitHub Projects
            </span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto mb-8">
            Real projects from my GitHub repository, automatically updated with new additions.
          </p>

          {/* Search and Filter Controls */}
          <div className="flex flex-col md:flex-row gap-4 justify-center items-center mb-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Search projects..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:border-cyan-500/50 w-64"
              />
              <svg
                className="absolute right-3 top-2.5 w-5 h-5 text-white/50"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>

            <div className="flex gap-2 flex-wrap justify-center">
              <button
                onClick={() => setSelectedTech(null)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  !selectedTech
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/30"
                    : "bg-white/10 text-white/70 border border-white/20 hover:bg-white/20"
                }`}
              >
                All
              </button>
              {technologies.map((tech) => (
                <button
                  key={tech}
                  onClick={() => setSelectedTech(tech)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                    selectedTech === tech
                      ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/30"
                      : "bg-white/10 text-white/70 border border-white/20 hover:bg-white/20"
                  }`}
                  style={{
                    borderColor: selectedTech === tech ? `${getLanguageColor(tech)}40` : undefined,
                    color: selectedTech === tech ? getLanguageColor(tech) : undefined,
                  }}
                >
                  {tech}
                </button>
              ))}
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Project Navigation */}
          <div className="space-y-4">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                className={`p-6 rounded-2xl cursor-pointer transition-all duration-300 ${
                  selectedProject === index
                    ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 shadow-lg"
                    : "bg-white/5 backdrop-blur-sm border border-white/10 hover:bg-white/10"
                }`}
                onClick={() => setSelectedProject(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-white mb-2">{project.name}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      {project.language && (
                        <span
                          className="text-xs px-2 py-1 rounded-full border"
                          style={{
                            backgroundColor: `${getLanguageColor(project.language)}20`,
                            borderColor: `${getLanguageColor(project.language)}40`,
                            color: getLanguageColor(project.language),
                          }}
                        >
                          {project.language}
                        </span>
                      )}
                      <span className="text-xs text-white/50">
                        Updated {new Date(project.updated_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-white/60">
                    <span>⭐ {project.stargazers_count}</span>
                    <span>🍴 {project.forks_count}</span>
                  </div>
                </div>
                <p className="text-white/70 text-sm line-clamp-2">
                  {project.description || "No description available"}
                </p>
              </motion.div>
            ))}

            {filteredProjects.length === 0 && (
              <div className="text-center py-12">
                <div className="text-4xl mb-4">🔍</div>
                <h3 className="text-xl font-semibold text-white mb-2">No projects found</h3>
                <p className="text-white/60">Try adjusting your search or filter criteria.</p>
              </div>
            )}
          </div>

          {/* Project Details */}
          {filteredProjects.length > 0 && (
            <div className="lg:sticky lg:top-24">
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedProject}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                  className="bg-white/10 backdrop-blur-md rounded-3xl overflow-hidden border border-white/20"
                >
                  {/* Project Header */}
                  <div className="relative h-64 bg-gradient-to-br from-cyan-500/20 to-purple-500/20 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-6xl mb-4">
                        {filteredProjects[selectedProject].language === "HTML"
                          ? "🌐"
                          : filteredProjects[selectedProject].language === "TypeScript"
                            ? "📘"
                            : filteredProjects[selectedProject].language === "JavaScript"
                              ? "📜"
                              : filteredProjects[selectedProject].language === "Python"
                                ? "🐍"
                                : "📁"}
                      </div>
                      <h3 className="text-2xl font-bold text-white">{filteredProjects[selectedProject].name}</h3>
                    </div>
                  </div>

                  <div className="p-8">
                    <div className="mb-6">
                      <div className="flex items-center gap-4 mb-4">
                        {filteredProjects[selectedProject].language && (
                          <span
                            className="px-3 py-1 rounded-full text-sm font-medium border"
                            style={{
                              backgroundColor: `${getLanguageColor(filteredProjects[selectedProject].language)}20`,
                              borderColor: `${getLanguageColor(filteredProjects[selectedProject].language)}40`,
                              color: getLanguageColor(filteredProjects[selectedProject].language),
                            }}
                          >
                            {filteredProjects[selectedProject].language}
                          </span>
                        )}
                        <div className="flex items-center gap-4 text-sm text-white/60">
                          <span className="flex items-center gap-1">
                            ⭐ {filteredProjects[selectedProject].stargazers_count}
                          </span>
                          <span className="flex items-center gap-1">
                            🍴 {filteredProjects[selectedProject].forks_count}
                          </span>
                        </div>
                      </div>
                    </div>

                    <p className="text-white/80 text-lg leading-relaxed mb-6">
                      {filteredProjects[selectedProject].description || "No description available for this repository."}
                    </p>

                    {/* Topics */}
                    {filteredProjects[selectedProject].topics &&
                      filteredProjects[selectedProject].topics.length > 0 && (
                        <div className="mb-6">
                          <h4 className="text-white font-semibold mb-3">Topics:</h4>
                          <div className="flex flex-wrap gap-2">
                            {filteredProjects[selectedProject].topics.map((topic, topicIndex) => (
                              <span
                                key={topicIndex}
                                className="px-3 py-1 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full text-sm text-cyan-300 border border-cyan-500/30"
                              >
                                {topic}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                    {/* Repository Info */}
                    <div className="mb-6 text-sm text-white/60">
                      <p>Created: {new Date(filteredProjects[selectedProject].created_at).toLocaleDateString()}</p>
                      <p>Last Updated: {new Date(filteredProjects[selectedProject].updated_at).toLocaleDateString()}</p>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-4">
                      <motion.a
                        href={filteredProjects[selectedProject].html_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full text-white font-semibold shadow-lg hover:shadow-cyan-500/25 transition-all duration-300"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        View on GitHub
                      </motion.a>

                      {filteredProjects[selectedProject].homepage && (
                        <motion.a
                          href={filteredProjects[selectedProject].homepage!}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-6 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full text-white font-semibold hover:bg-white/20 transition-all duration-300"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          Live Demo
                        </motion.a>
                      )}

                      <motion.button
                        onClick={() => setShowPlayground(true)}
                        className="px-6 py-3 bg-purple-500/20 border border-purple-500/30 rounded-full text-purple-300 font-semibold hover:bg-purple-500/30 transition-all duration-300"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Try Code
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Code Playground Modal */}
        <AnimatePresence>
          {showPlayground && filteredProjects.length > 0 && (
            <CodePlayground
              code={generateDemoCode(filteredProjects[selectedProject])}
              title={filteredProjects[selectedProject].name}
              onClose={() => setShowPlayground(false)}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
