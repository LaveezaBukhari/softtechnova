import { NextResponse } from "next/server"
import { fetchGitHubStats } from "@/lib/github-api"

export async function GET() {
  try {
    const stats = await fetchGitHubStats()

    return NextResponse.json(stats, {
      headers: {
        "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
      },
    })
  } catch (error) {
    console.error("GitHub stats API error:", error)

    // Always return a successful response with fallback data
    const fallbackStats = {
      totalRepos: 9,
      totalStars: 0,
      totalForks: 0,
      totalCommits: 45,
      contributions: 38,
      user: {
        login: "SardarMuhammadAhsanKhan",
        name: "Sardar Muhammad Ahsan Khan",
        bio: "Creative Technologist & Developer",
        public_repos: 9,
        followers: 0,
        following: 0,
        created_at: "2024-01-01T00:00:00Z",
      },
    }

    return NextResponse.json(fallbackStats, {
      status: 200,
      headers: {
        "Cache-Control": "public, s-maxage=60, stale-while-revalidate=120",
      },
    })
  }
}
