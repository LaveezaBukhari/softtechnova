import { NextResponse } from "next/server"
import { fetchGitHubRepos } from "@/lib/github-api"

export async function GET() {
  try {
    const repos = await fetchGitHubRepos()

    return NextResponse.json(repos, {
      headers: {
        "Cache-Control": "public, s-maxage=300, stale-while-revalidate=600",
      },
    })
  } catch (error) {
    console.error("GitHub repos API error:", error)

    // Return comprehensive fallback data based on your actual repositories
    const fallbackRepos = [
      {
        id: 1,
        name: "Grocermate",
        full_name: "SardarMuhammadAhsanKhan/Grocermate",
        description: "A comprehensive grocery management application for efficient shopping and inventory tracking",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/Grocermate",
        homepage: null,
        language: "HTML",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-06-01T00:00:00Z",
        updated_at: "2024-06-15T00:00:00Z",
        topics: ["grocery", "management", "shopping", "inventory"],
        private: false,
      },
      {
        id: 2,
        name: "fyp",
        full_name: "SardarMuhammadAhsanKhan/fyp",
        description: "Final Year Project - A comprehensive web application built with modern technologies",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/fyp",
        homepage: null,
        language: "TypeScript",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-05-01T00:00:00Z",
        updated_at: "2024-06-10T00:00:00Z",
        topics: ["final-year-project", "typescript", "web-development"],
        private: false,
      },
      {
        id: 3,
        name: "fyp-2",
        full_name: "SardarMuhammadAhsanKhan/fyp-2",
        description: "Final Year Project - Version 2 with enhanced features and improvements",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/fyp-2",
        homepage: null,
        language: "JavaScript",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-05-15T00:00:00Z",
        updated_at: "2024-06-05T00:00:00Z",
        topics: ["final-year-project", "javascript", "web-app"],
        private: false,
      },
      {
        id: 4,
        name: "myfirst",
        full_name: "SardarMuhammadAhsanKhan/myfirst",
        description: "My first repository - Learning the basics of web development",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/myfirst",
        homepage: null,
        language: "HTML",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-04-01T00:00:00Z",
        updated_at: "2024-04-15T00:00:00Z",
        topics: ["learning", "html", "beginner"],
        private: false,
      },
      {
        id: 5,
        name: "localrepo",
        full_name: "SardarMuhammadAhsanKhan/localrepo",
        description: "Local repository for testing and experimentation",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/localrepo",
        homepage: null,
        language: "JavaScript",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-03-01T00:00:00Z",
        updated_at: "2024-03-15T00:00:00Z",
        topics: ["testing", "local-development"],
        private: false,
      },
      {
        id: 6,
        name: "test",
        full_name: "SardarMuhammadAhsanKhan/test",
        description: "Test repository for various experiments and code testing",
        html_url: "https://github.com/SardarMuhammadAhsanKhan/test",
        homepage: null,
        language: "Python",
        stargazers_count: 0,
        forks_count: 0,
        created_at: "2024-02-01T00:00:00Z",
        updated_at: "2024-02-15T00:00:00Z",
        topics: ["test", "python", "experiments"],
        private: false,
      },
    ]

    return NextResponse.json(fallbackRepos, {
      status: 200,
      headers: {
        "Cache-Control": "public, s-maxage=60, stale-while-revalidate=120",
      },
    })
  }
}
