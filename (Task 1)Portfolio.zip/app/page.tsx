"use client"

import { useState, useEffect } from "react"
import { Canvas } from "@react-three/fiber"
import { Suspense } from "react"
import { Navigation } from "@/components/navigation"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { SkillsSection } from "@/components/skills-section"
import { ProjectsSection } from "@/components/projects-section"
import { TestimonialsSection } from "@/components/testimonials-section"
import { ContactSection } from "@/components/contact-section"
import { AIAssistant } from "@/components/ai-assistant"
import { CustomCursor } from "@/components/custom-cursor"
import { ThreeBackground } from "@/components/three-background"
import { VoiceCommands } from "@/components/voice-commands"
import { EasterEgg } from "@/components/easter-egg"
import { GitHubStats } from "@/components/github-stats"
import { ScrollProgress } from "@/components/scroll-progress"
import { BackToTop } from "@/components/back-to-top"
import { LoadingScreen } from "@/components/loading-screen"
import { ThemeProvider } from "@/components/theme-provider"

export default function Portfolio() {
  const [currentSection, setCurrentSection] = useState("hero")
  const [konamiActivated, setKonamiActivated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      const sections = ["hero", "about", "skills", "projects", "testimonials", "contact"]
      const scrollPosition = window.scrollY + window.innerHeight / 2

      for (const section of sections) {
        const element = document.getElementById(section)
        if (element) {
          const { offsetTop, offsetHeight } = element
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setCurrentSection(section)
            break
          }
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  if (isLoading) {
    return <LoadingScreen />
  }

  return (
    <ThemeProvider>
      <div className="relative min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 dark:from-black dark:via-purple-950 dark:to-black overflow-x-hidden">
        {/* 3D Background */}
        <div className="fixed inset-0 z-0">
          <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
            <Suspense fallback={null}>
              <ThreeBackground />
            </Suspense>
          </Canvas>
        </div>

        {/* Custom Cursor */}
        <CustomCursor />

        {/* Scroll Progress */}
        <ScrollProgress />

        {/* Navigation */}
        <Navigation currentSection={currentSection} />

        {/* Main Content */}
        <main className="relative z-10">
          <section id="hero">
            <HeroSection />
          </section>

          <section id="about">
            <AboutSection />
          </section>

          <section id="skills">
            <SkillsSection />
          </section>

          <section id="projects">
            <ProjectsSection />
          </section>

          <section id="testimonials">
            <TestimonialsSection />
          </section>

          <section id="contact">
            <ContactSection />
          </section>
        </main>

        {/* GitHub Stats */}
        <GitHubStats />

        {/* AI Assistant */}
        <AIAssistant />

        {/* Voice Commands */}
        <VoiceCommands onSectionChange={setCurrentSection} />

        {/* Back to Top */}
        <BackToTop />

        {/* Easter Egg */}
        <EasterEgg isActivated={konamiActivated} onActivate={() => setKonamiActivated(true)} />
      </div>
    </ThemeProvider>
  )
}
